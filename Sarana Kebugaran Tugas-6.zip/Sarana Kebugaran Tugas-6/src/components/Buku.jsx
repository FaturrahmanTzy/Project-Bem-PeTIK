
const Buku = ({ buku }) => {
    return (
        <div>
            <h2>Daftar Buku</h2>
            <ul>
                <li>{buku}</li>
            </ul>
        </div>
    );
};

export default Buku;