import React, { useState } from 'react';
import './Form.css';
const Form = ({ addAlat}) => {

        const [formData, setFormData] = useState({
            alat: "",
            material: "",
            warna: "",
            berat: "",
            img: "",
            
        });
    
        const handleChange = (event) => {
            const { name, value} = event.target;
    
            setFormData((prevData) => ({
                ...prevData,
                [name]: value
            }));
        };
        
    
        const handleSubmit = (event) => {
            event.preventDefault();
            alert(`Data berhasil dikirim:\n${JSON.stringify(formData, null, 2)}`);
        };

       const newAlat = {
      id: Date.now(), // ID unik
      ...formData,
    };

    addAlat(newAlat); // Kirim data ke parent (Alat1)
    
    // Reset form setelah submit
  
        
    return (
        <>
            <h2>Data Alat Fitness</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="alat">Alat :</label>
                <input type="text" id="alat" name="alat" value={formData.alat}  onChange={handleChange} required placeholder='Nama Alat'  />
                <br />
                <label htmlFor="material">Material :</label>
                <input type="text" id="material" name="material" value={formData.material} onChange={handleChange} required  placeholder='Material Alat'/>
                <br />
                <label htmlFor="warna">Warna :</label>
                <input type="text" id="warna" name="warna" value={formData.warna} onChange={handleChange} required  placeholder='Warna Alat'/>
                <br />
                <label htmlFor="berat">Berat :</label>
                <input type="text" id="berat" name="berat" value={formData.berat} onChange={handleChange} required  placeholder='Berat Alat'/>
                <br />
                <label htmlFor="img">Gambar :</label>
                <input type="text" id="img" name="img" value={formData.img} onChange={handleChange} required  placeholder='Link Gambar Alat'/>
                <br />
                <button type="submit">Kirim</button>
            </form>
        </>
    );
}    

export default Form
