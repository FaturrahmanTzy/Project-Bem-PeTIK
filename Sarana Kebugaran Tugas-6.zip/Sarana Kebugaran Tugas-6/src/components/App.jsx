// App.js
import { Component } from 'react';
import Header from './Header/Header';
import Footer from './Footer/Footer';
import '../App.css';
import Alat1 from './Alat/Alat';
import Buku from './Buku'
import Frofil from './Frofil/Frofile'
import Form from './Form/Form';



const App = () => {
    const gambargym = "https://cdn2.uzone.id/assets/uploads/feeding/861e65c1ab7832cb5410d26d32e5a8f0.jpg"
    return (
        <div>
            <Header />
            <Frofil foto={gambargym}/>
            <Alat1 />
            <Buku buku="Kebugaran fisik bukan hanya tentang penampilan, tetapi juga tentang kesehatan dan kualitas hidup. Dengan berolahraga secara teratur, Anda dapat meningkatkan kesehatan jantung, mengurangi risiko penyakit, dan meningkatkan energi serta produktivitas."/>
            <Footer nama="Fatur" />
        </div>
    );
    }

export default App;