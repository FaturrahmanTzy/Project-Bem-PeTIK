import Header from "../components/Header/Header";
import Frofil from "../components/Frofil/Frofile";
import Alat1 from "../components/Alat/Alat";
import Footer from "../components/Footer/Footer";

const Home = () => {
    const gambargym = "https://cdn2.uzone.id/assets/uploads/feeding/861e65c1ab7832cb5410d26d32e5a8f0.jpg"
    return (
        <div> 
            <Header/>
         <section className="mt-6 text-center">
                <h2 className="text-2xl font-bold">Selamat Datang di Sarana Kebugaran</h2>
                <p className="text-gray-700 mt-2," style={{textAlign: "center"}}>Temukan berbagai alat kebugaran terbaik untuk latihan di rumah maupun di gym profesional.</p>
                <Frofil foto={gambargym}/>
                <Alat1/>
            <Footer nama="Fatur" />
            </section>
        </div>
    );
}

export default Home