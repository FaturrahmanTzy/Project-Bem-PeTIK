import { NavLink, useNavigate } from 'react-router-dom';

const ErrorPage = () => {
    const navigate = useNavigate();
    return (
        <div>
            <h3>404 Halaman Tidak Ditemukan</h3>
            <p>Opps... Halaman yang Kamu cari tidak ada</p>
            <button onClick={(() => navigate(-1))}>Kembali</button>
            <NavLink to={"/"} style={
            {textDecoration: "none",
             color: "black" ,
             fontWeight: "bold",
             border: "1px solid black" ,
             padding: "10px" , 
             borderRadius: "10px",

             }}>Kembali ke Home</NavLink>
        </div>
    );
}

export default ErrorPage