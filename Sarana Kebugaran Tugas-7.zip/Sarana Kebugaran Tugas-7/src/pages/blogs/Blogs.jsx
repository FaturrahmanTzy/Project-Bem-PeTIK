import Alat from "../../components/Alat/Alat";
import Header from "../../components/Header/Header";

const Blogs = () => {
    return (
        
        <div>
            <Header/>
            <Alat/>
        </div>
    );
}

export default Blogs