import Buku from "../components/Buku";
import Header from "../components/Header/Header";


const About = () => {
    return (
        <div>
            <Header/>
            <Buku/>
            <h2>Tentang Kebugaran Fisik</h2>
            <ul>
                <li><p>Kebugaran fisik bukan hanya tentang penampilan, tetapi juga tentang kesehatan dan kualitas hidup secara keseluruhan. Berolahraga secara teratur membantu menjaga kesehatan jantung, meningkatkan sirkulasi darah, dan mengurangi risiko berbagai penyakit kronis seperti diabetes, tekanan darah tinggi, dan obesitas. Selain itu, aktivitas fisik yang rutin juga berperan dalam meningkatkan daya tahan tubuh, memperbaiki kualitas tidur, serta menjaga keseimbangan hormon yang berkontribusi pada kesehatan mental.

                    Tak hanya manfaat fisik, kebugaran juga berdampak positif pada kesehatan mental dan emosional. Olahraga dapat merangsang pelepasan endorfin, hormon yang membantu mengurangi stres, kecemasan, dan depresi, sehingga Anda merasa lebih bahagia dan rileks. Selain itu, dengan tubuh yang lebih bugar, Anda akan merasakan peningkatan energi sepanjang hari, yang pada akhirnya dapat meningkatkan produktivitas dan kualitas hidup secara keseluruhan.

                Menjadikan olahraga sebagai bagian dari gaya hidup bukan hanya investasi untuk kesehatan saat ini, tetapi juga untuk masa depan yang lebih baik. Dengan menjaga kebugaran tubuh, Anda dapat menjalani kehidupan yang lebih aktif, bebas dari berbagai masalah kesehatan, serta menikmati momen-momen berharga bersama orang-orang tercinta dalam kondisi yang prima.
                    </p>
                </li>
            </ul>        
        </div>
    );
}

export default About