
import React from 'react';
import './Alat.css';
import { useState } from 'react';
import posts from '../posts.json';
import Form from '../Form/Form';

const Alat1 = () => {
 
  const [search, setSearch] = useState("");

  


    const handleChangeSearch = (event) => {
      setSearch(event.target.value)

    }

    const filteredAlat = posts.filter((alat) =>
      alat.nama.toLowerCase().includes(search.toLowerCase())
    );

    
  return (
    <div>
      <Form/>
      <br />
      <p>Cari Alat Fitness: <input type="text"  onChange={handleChangeSearch} placeholder="Search..."/></p>
       <small>Ditemukan {filteredAlat.length} data dengan pencarian kata {search}</small>
                
      
      <ol>
        {
        filteredAlat.map((alat) => (
          <li key={alat.id}>
            <h3>{alat.nama}</h3>
            <p>Material: {alat.material}</p>
            <p>Warna: {alat.warna}</p>
            <p>Berat: {alat.berat}</p>
            <p><img src={alat.img} alt="gambar alat"/></p>
          </li>
        ))}
      </ol>
    </div>
  );
}


export default Alat1;