
const Buku = () => {
    return (
        <div>
            <h2>Daftar Buku</h2>
            <ul>
                <li>Kebugaran fisik bukan hanya tentang penampilan, tetapi juga tentang kesehatan dan kualitas hidup. Dengan berolahraga secara teratur, Anda dapat meningkatkan kesehatan jantung, mengurangi risiko penyakit, dan meningkatkan energi serta produktivitas.</li>
            </ul>
        </div>
    );
}; 


export default Buku;