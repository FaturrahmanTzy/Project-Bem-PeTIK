
import React from 'react'
import './Frofil.css'
const Frofil = ({foto}) => {
    return (
        <div>
            <h2>Gambar Gym</h2>
            <img src={foto} alt="Gambar Gym" />
        </div>
    )
}

export default Frofil