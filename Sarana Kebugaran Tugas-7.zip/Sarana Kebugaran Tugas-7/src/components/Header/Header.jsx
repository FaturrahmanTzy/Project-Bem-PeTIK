import { Component } from 'react';
import './Header.css';
import { NavLink } from 'react-router-dom';
const Header = () => {
    return (
        <header>
            <h1>Sarana Kebugaran</h1>
            <nav>
                <ul>
                    <li> 
                        <NavLink to="/" className={({isActive}) => isActive ? "active" : ""}>Home</NavLink>
                    </li>
                    <li>
                        <NavLink to="/about" className={({isActive}) => isActive ? "active" : ""}>Buku</NavLink>
                    </li>
                    <li>
                        <NavLink to="/alat" className={({isActive}) => isActive ? "active" : ""}>Alat</NavLink>
                    </li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;