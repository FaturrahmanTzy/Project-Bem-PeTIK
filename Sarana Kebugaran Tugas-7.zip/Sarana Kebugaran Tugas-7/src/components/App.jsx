// App.js
import { Component } from 'react';
import '../App.css';
import About from '../pages/About';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from '../pages/index';
import Blog from '../pages/About';
import ErrorPage from '../pages/blogs/ErrorPage';
import Blogs from '../pages/blogs/Blogs';



const App = () => {
    return (
        <div>
      <BrowserRouter>
        <Routes>
          <Route path = '/' element = {<Home />}/>
          <Route path = "/Alat" element = { <Blogs/>}/>
          <Route path = "/about" element = { <About/> }/>
          <Route path = "*" element = { <ErrorPage/>} />
        </Routes>
      </BrowserRouter>
        </div>
    );
    }

export default App;